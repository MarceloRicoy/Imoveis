<?php
 
   $con = mysqli_connect('localhost','root','root','unityacess');


   //check 
   if(mysqli_connect_errno())
   {
   	echo "1: Connection Failed";
   	exit();
   }
   $idApartamento = $_POST["idApartamento"];
   $qtdQuartos = $_POST["qtdQuartos"];
   $qtdsuite = $_POST["qtdSuites"];
   $qtdSalaEstar = $_POST["qtdSalaEstar"];
   $area = $_POST["qtdArea"];
   $armarioEmbutido = $_POST["armarioEmbutido"];
   $vagasGaragem = $_POST["vagasGaragem"];
   $descricao = $_POST["descricao"];
   $condominio = $_POST["condominio"];
   $qtdSalaJantar = $_POST["qtdSalaJantar"];
   $portaria = $_POST["portaria"];
   $aluguel = $_POST["aluguel"];
   $bairro = $_POST["bairro"];

   $insertImovelquery = "INSERT INTO apartamentos (idApartamento,qtdQuartos,qtdsuite,qtdSalaEstar,area,armarioEmbutido,vagasGaragem,descricao,condominio,qtdSalaJantar,portaria,aluguel,bairro) VALUES ($idApartamento,$qtdQuartos,$qtdsuite,$qtdSalaEstar,$area,$armarioEmbutido,$vagasGaragem,'$descricao',$condominio,$qtdSalaJantar,$portaria,$aluguel,'$bairro');";

   mysqli_query($con,$insertImovelquery) or die( (mysqli_error($con)));

   echo("0");
?>