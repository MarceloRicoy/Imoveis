<?php
  
   $con = mysqli_connect('localhost','root','root','unityacess');

   //check 
   if(mysqli_connect_errno())
   {
   	echo "1: Connection Failed";
   	exit();
   }

   $sql = "SELECT nome FROM bairros";
   
   $result = mysqli_query($con,$sql)or die( (mysqli_error($con)));

   if($result->num_rows>0)
   {
      while($row =mysql_fetch_array($result))
      {
        echo "nome" . $row["nome"];
      }
   }

      echo("0");
?>