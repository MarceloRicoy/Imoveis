<?php
  
   $con = mysqli_connect('localhost','root','root','unityacess');


   //check 
   if(mysqli_connect_errno())
   {
   	echo "1: Connection Failed";
   	exit();
   }

   $idImovel = $_POST["idImovel"];
   $qtdQuartos = $_POST["qtdQuartos"];
   $qtdsuite = $_POST["qtdSuites"];
   $qtdSalaEstar = $_POST["qtdSalaEstar"];
   $area = $_POST["qtdArea"];
   $armarioEmbutido = $_POST["armarioEmbutido"];
   $vagasGaragem = $_POST["vagasGaragem"];
   $descricao = $_POST["descricao"];
   $bairro = $_POST["bairro"];
   $aluguel = $_POST["aluguel"];
   
    
   $insertImovelquery = "INSERT INTO imoveis (idImovel,qtdQuartos,qtdsuite,qtdSalaEstar,area,armarioEmbutido,vagasGaragem,descricao,bairro,aluguel) VALUES ($idImovel,$qtdQuartos,$qtdsuite,$qtdSalaEstar, $area,$armarioEmbutido,$vagasGaragem,'$descricao','$bairro',$aluguel);";

   mysqli_query($con,$insertImovelquery) or die( (mysqli_error($con)));

   echo("0");


?>