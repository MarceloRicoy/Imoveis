-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 01, 2020 at 02:20 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unityacess`
--

-- --------------------------------------------------------

--
-- Table structure for table `apartamentos`
--

CREATE TABLE `apartamentos` (
  `idApartamento` int(10) NOT NULL,
  `qtdQuartos` int(11) NOT NULL DEFAULT '0',
  `qtdsuite` int(11) NOT NULL DEFAULT '0',
  `qtdSalaEstar` int(11) NOT NULL DEFAULT '0',
  `area` int(11) NOT NULL DEFAULT '0',
  `armarioEmbutido` tinyint(1) NOT NULL DEFAULT '0',
  `vagasGaragem` int(11) NOT NULL DEFAULT '0',
  `descricao` varchar(30) NOT NULL DEFAULT 'a',
  `qtdSalaJantar` int(11) NOT NULL DEFAULT '0',
  `condominio` int(11) NOT NULL DEFAULT '0',
  `portaria` tinyint(1) NOT NULL DEFAULT '0',
  `aluguel` int(11) NOT NULL DEFAULT '0',
  `bairro` varchar(30) NOT NULL DEFAULT 'b'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `apartamentos`
--

INSERT INTO `apartamentos` (`idApartamento`, `qtdQuartos`, `qtdsuite`, `qtdSalaEstar`, `area`, `armarioEmbutido`, `vagasGaragem`, `descricao`, `qtdSalaJantar`, `condominio`, `portaria`, `aluguel`, `bairro`) VALUES
(33, 2121, 121, 12, 12, 0, 0, 'a', 0, 0, 0, 0, 'b'),
(123, 323, 44, 55, 66, 1, 1223, 'assadsad', 23, 444, 1, 232323, 'b'),
(1423, 0, 0, 0, 0, 0, 0, 'a', 0, 0, 0, 0, 'b'),
(2112, 2323, 3, 32, 1, 1, 0, 'a', 0, 0, 0, 0, 'b'),
(2525, 1, 2, 3, 4, 1, 5, 'aiuit', 1, 2, 1, 3, 'aiuit'),
(6677, 123, 2, 3, 4, 1, 12, 'oioi', 3, 2, 1, 1, 'nono'),
(12312, 3213, 21, 0, 0, 0, 0, 'a', 0, 0, 0, 0, 'b'),
(12323, 32323, 0, 0, 0, 0, 0, 'a', 0, 0, 0, 0, 'b'),
(122266, 12, 23, 45, 6, 1, 2, 'sasdasd', 223, 4, 1, 56, 'sasdasd'),
(123231237, 32323, 2323, 2332, 0, 0, 0, 'a', 0, 0, 0, 0, 'b');

-- --------------------------------------------------------

--
-- Table structure for table `bairros`
--

CREATE TABLE `bairros` (
  `idBairro` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL DEFAULT 'nenhum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `imoveis`
--

CREATE TABLE `imoveis` (
  `idImovel` int(10) NOT NULL,
  `qtdQuartos` int(11) NOT NULL DEFAULT '0',
  `qtdsuite` int(11) NOT NULL DEFAULT '0',
  `qtdSalaEstar` int(11) NOT NULL DEFAULT '0',
  `area` int(11) NOT NULL DEFAULT '0',
  `armarioEmbutido` tinyint(1) DEFAULT '0',
  `vagasGaragem` int(11) NOT NULL DEFAULT '0',
  `descricao` varchar(30) NOT NULL DEFAULT 'a',
  `Bairro` varchar(20) NOT NULL DEFAULT 'nenhum',
  `aluguel` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `imoveis`
--

INSERT INTO `imoveis` (`idImovel`, `qtdQuartos`, `qtdsuite`, `qtdSalaEstar`, `area`, `armarioEmbutido`, `vagasGaragem`, `descricao`, `Bairro`, `aluguel`) VALUES
(11, 23, 4, 5, 6, 1, 123, 'asdadsadasd', '', 0),
(12, 0, 0, 0, 0, 0, 0, 'a', '', 0),
(15, 0, 0, 0, 0, 0, 0, 'a', '', 0),
(16, 2, 3, 4, 5, 1, 23, 'a', '', 0),
(21, 11, 23, 11, 2, 1, 23, 'asdasd', ' asdas asa', 111),
(25, 3, 23, 1, 23, 1, 1, 'asdasd', 'santa branca', 0),
(1112, 2, 3, 4, 1, 1, 2, 'wewewe', 'lalala', 123),
(1223, 4, 0, 0, 0, 0, 0, 'a', '', 0),
(3222, 22, 3, 2, 1, 1, 2323, 'deucerto', 'vlw', 89),
(12345, 1, 2, 3, 44, 1, 22, 'asdasdasdas', 'sss aaa', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apartamentos`
--
ALTER TABLE `apartamentos`
  ADD PRIMARY KEY (`idApartamento`);

--
-- Indexes for table `bairros`
--
ALTER TABLE `bairros`
  ADD PRIMARY KEY (`idBairro`);

--
-- Indexes for table `imoveis`
--
ALTER TABLE `imoveis`
  ADD PRIMARY KEY (`idImovel`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apartamentos`
--
ALTER TABLE `apartamentos`
  MODIFY `idApartamento` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123231238;

--
-- AUTO_INCREMENT for table `imoveis`
--
ALTER TABLE `imoveis`
  MODIFY `idImovel` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12346;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
