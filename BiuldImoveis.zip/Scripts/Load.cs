﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Load : MonoBehaviour
{
   public void LoadCasa()
    {
        SceneManager.LoadScene("Register");
    }
    public void LoadApartamento()
    {
     SceneManager.LoadScene("RegisterApart");
    }
    public void Menu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
