﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReceiveData : MonoBehaviour
{
    public void CallReceive()
    {
        StartCoroutine(Receive());
    }


    IEnumerator Receive()
    {
        WWW request = new WWW("http://localhost/sqlconnect/receivedata.php");

        yield return request;
        if (request.text == "0")
        {
            Debug.Log("sucess");
        }

        else
        {
            Debug.Log(request.text);
        }
    }
}
