﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using System;
public class Register : MonoBehaviour
{
    [SerializeField] private InputField idImovel;
    [SerializeField] private InputField qtdQuartos;
    [SerializeField] private InputField qtdSuites;
    [SerializeField] private InputField qtdSalaEstar;
    [SerializeField] private InputField qtdArea;
    [SerializeField] private Toggle armarioEmbutido;
    [SerializeField] private InputField vagasGaragem;
    [SerializeField] private InputField descricao;
    [SerializeField] private InputField bairro;
    [SerializeField] private InputField aluguel;
    public void CallRegister()
    {
        StartCoroutine(Registration());
    }

    IEnumerator Registration()
    {
        WWWForm form = new WWWForm();
        form.AddField("idImovel",int.Parse(idImovel.text));
        form.AddField("qtdQuartos", int.Parse(qtdQuartos.text));
        form.AddField("qtdSuites", int.Parse(qtdSuites.text));
        form.AddField("qtdSalaEstar", int.Parse(qtdSalaEstar.text));
        form.AddField("qtdArea", int.Parse(qtdArea.text));
        form.AddField("armarioEmbutido",Convert.ToInt32(armarioEmbutido.isOn));
        form.AddField("vagasGaragem", int.Parse(vagasGaragem.text));
        form.AddField("descricao", descricao.text);
        form.AddField("bairro", bairro.text);
        form.AddField("aluguel", int.Parse(aluguel.text));


        WWW www = new WWW("http://localhost/sqlconnect/register.php",form);
        yield return www;

        if(www.text=="0")
        {
            Debug.Log("sucess");
        }
        else
        {
            Debug.Log(www.text);
        }

    }
}
